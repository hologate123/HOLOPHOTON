import { type Contact, type InsertContact } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  createContactInquiry(inquiry: InsertContact): Promise<Contact>;
  getContactInquiries(): Promise<Contact[]>;
}

export class MemStorage implements IStorage {
  private inquiries: Map<string, Contact>;

  constructor() {
    this.inquiries = new Map();
  }

  async createContactInquiry(insertInquiry: InsertContact): Promise<Contact> {
    const id = randomUUID();
    const inquiry: Contact = {
      ...insertInquiry,
      id,
      createdAt: new Date(),
    };
    this.inquiries.set(id, inquiry);
    return inquiry;
  }

  async getContactInquiries(): Promise<Contact[]> {
    return Array.from(this.inquiries.values()).sort(
      (a, b) => b.createdAt.getTime() - a.createdAt.getTime()
    );
  }
}

export const storage = new MemStorage();
