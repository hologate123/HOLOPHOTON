import {
  Shield,
  ChevronDown,
  ArrowRight,
  Atom,
  Waves,
  Zap,
  Cpu,
  Thermometer,
  Sparkles,
  Box,
  Layers,
  CircuitBoard,
} from "lucide-react";
import chipImage from "@assets/generated_images/futuristic_photonic_processor_chip.png";
import PhotonicBlob from "@/components/PhotonicBlob";

function Navigation() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/5 backdrop-blur-xl border-b border-white/10">
      <div className="max-w-7xl mx-auto px-5 sm:px-8 py-4 sm:py-6 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="font-bold text-2xl tracking-tight" data-testid="logo-text">
            HOLO
          </span>
        </div>

        <div className="hidden md:flex items-center gap-12">
          <button
            onClick={() => scrollToSection("chip")}
            className="text-sm text-white/80 hover:text-white transition-colors uppercase tracking-widest"
            data-testid="nav-chip"
          >
            Technology
          </button>
          <button
            onClick={() => scrollToSection("safety")}
            className="text-sm text-white/80 hover:text-white transition-colors uppercase tracking-widest"
            data-testid="nav-safety"
          >
            Performance
          </button>
          <button
            onClick={() => scrollToSection("sovereignty")}
            className="text-sm text-white/80 hover:text-white transition-colors uppercase tracking-widest"
            data-testid="nav-sovereignty"
          >
            Sovereignty
          </button>
        </div>

      </div>
    </nav>
  );
}

function HeroSection() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden">
      <PhotonicBlob />

      <div className="relative z-20 max-w-5xl mx-auto px-5 sm:px-8 text-center mt-24">
        <p className="text-sm uppercase tracking-[0.3em] text-white/70 mb-8">
          Photonic Integrated Circuits
        </p>

        <h1
          className="text-5xl sm:text-6xl md:text-8xl lg:text-9xl font-bold tracking-tighter mb-8"
          data-testid="hero-headline"
        >
          Beyond
          <br />
          Silicon
        </h1>

        <p
          className="text-lg md:text-xl text-white/80 max-w-2xl mx-auto mb-16 leading-relaxed font-light"
          data-testid="hero-subheadline"
        >
          A new class of photonic integrated circuit that computes with light.
          <br />
          No heat. No limits. Pure intelligence.
        </p>

        <button
          onClick={() => scrollToSection("chip")}
          className="group inline-flex items-center gap-3 text-sm uppercase tracking-[0.2em] text-white/80 hover:text-white transition-all"
          data-testid="button-hero-cta"
        >
          <span>Discover</span>
          <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
        </button>
      </div>

      <button
        onClick={() => scrollToSection("chip")}
        className="absolute bottom-12 left-1/2 -translate-x-1/2 text-white/60 hover:text-white/80 transition-colors z-20"
        data-testid="button-scroll-down"
      >
        <ChevronDown className="w-6 h-6 animate-bounce" />
      </button>
    </section>
  );
}

function ChipSection() {
  return (
    <section id="chip" className="py-20 md:py-48 relative">
      <div className="max-w-7xl mx-auto px-5 sm:px-8">
        <div className="grid lg:grid-cols-2 gap-20 items-center">
          <div>
            <p className="text-sm uppercase tracking-[0.3em] text-photonic-cyan mb-6">
              The Core
            </p>

            <h2
              className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold tracking-tight mb-8"
              data-testid="chip-headline"
            >
              The HOLO
              <br />
              PIC
            </h2>

            <p className="text-lg text-white/80 mb-12 leading-relaxed font-light max-w-lg">
              A breakthrough in photonic integrated circuits. We have engineered a PIC
              that thinks in light, computing at speeds and efficiencies that
              electronics cannot achieve.
            </p>

            <div className="space-y-8">
              {[
                {
                  icon: CircuitBoard,
                  title: "Photonic Core",
                  description: "Light as logic. An entirely new computing paradigm.",
                },
                {
                  icon: Layers,
                  title: "Multi-Layer Integration",
                  description: "Stacked waveguide architecture at nanometer precision.",
                },
                {
                  icon: Shield,
                  title: "Secure Envelope",
                  description: "Protected by the physics of light itself.",
                },
              ].map((item, index) => (
                <div
                  key={index}
                  className="flex items-start gap-4"
                  data-testid={`chip-pillar-${index}`}
                >
                  <div className="w-10 h-10 rounded-lg bg-white/5 backdrop-blur-md border border-white/10 flex items-center justify-center flex-shrink-0">
                    <item.icon className="w-5 h-5 text-photonic-cyan" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">{item.title}</h3>
                    <p className="text-sm text-white/70">{item.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="relative">
            <div className="relative aspect-square">
              <div className="absolute inset-0 bg-gradient-to-br from-photonic-cyan/10 via-transparent to-plasma-violet/10 rounded-3xl blur-3xl" />
              <div className="relative rounded-2xl overflow-hidden border border-white/10 bg-white/5 backdrop-blur-md">
                <img
                  src={chipImage}
                  alt="HOLO Photonic Processor"
                  className="w-full h-full object-cover"
                  data-testid="chip-image"
                />
              </div>
            </div>
          </div>
        </div>

        <div className="mt-32 grid md:grid-cols-3 gap-6">
          {[
            {
              icon: CircuitBoard,
              label: "On-Chip Routing",
              description: "Integrated optical waveguides",
            },
            {
              icon: Waves,
              label: "Signal Integrity",
              description: "Low-loss photonic transmission",
            },
            {
              icon: Atom,
              label: "Quantum-Ready",
              description: "Compatible with emerging architectures",
            },
          ].map((feature, index) => (
            <div
              key={index}
              className="p-10 bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 text-center"
              data-testid={`chip-feature-${index}`}
            >
              <feature.icon className="w-8 h-8 text-photonic-cyan mx-auto mb-6" />
              <h3 className="text-xl font-semibold mb-2">{feature.label}</h3>
              <p className="text-white/70">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function SafetySection() {
  return (
    <section id="safety" className="py-20 md:py-48 relative border-t border-white/5">
      <div className="max-w-7xl mx-auto px-5 sm:px-8">
        <div className="max-w-3xl">
          <p className="text-sm uppercase tracking-[0.3em] text-plasma-violet mb-6">
            Chip Architecture
          </p>

          <h2
            className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold tracking-tight mb-8"
            data-testid="safety-headline"
          >
            Built For
            <br />
            Performance
          </h2>

          <p className="text-lg text-white/80 mb-16 leading-relaxed font-light">
            Our photonic processor redefines computational boundaries.
            Light-speed data pathways unlock capabilities beyond silicon limits.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {[
            {
              icon: Zap,
              title: "Photonic Pathways",
              metric: "Light-Speed",
              description: "Data moves at the speed of light through optical channels",
            },
            {
              icon: Cpu,
              title: "Parallel Processing",
              metric: "Massive",
              description: "Simultaneous computation across wavelength domains",
            },
            {
              icon: Thermometer,
              title: "Thermal Efficiency",
              metric: "Ultra-Low",
              description: "Near-zero heat generation compared to electronics",
            },
          ].map((feature, index) => (
            <div
              key={index}
              className="p-10 bg-white/5 backdrop-blur-md rounded-2xl border border-white/10"
              data-testid={`safety-card-${index}`}
            >
              <feature.icon className="w-8 h-8 text-plasma-violet mb-6" />
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-white/70 mb-6">{feature.description}</p>
              <div className="pt-6 border-t border-white/10">
                <span className="text-2xl font-bold font-mono text-plasma-violet">
                  {feature.metric}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function SovereigntySection() {
  return (
    <section id="sovereignty" className="py-20 md:py-48 relative border-t border-white/5">
      <div className="max-w-7xl mx-auto px-5 sm:px-8">
        <div className="grid lg:grid-cols-2 gap-20 items-start">
          <div>
            <p className="text-sm uppercase tracking-[0.3em] text-photonic-cyan mb-6">
              European Leadership
            </p>

            <h2
              className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold tracking-tight mb-8"
              data-testid="sovereignty-headline"
            >
              Technological
              <br />
              Sovereignty
            </h2>

            <p className="text-lg text-white/80 leading-relaxed font-light">
              HOLO represents a new chapter in European deep-tech leadership.
              Our photonic integrated circuits are designed, developed, and fabricated
              entirely within sovereign European infrastructure.
            </p>
          </div>

          <div className="space-y-6">
            <div
              className="p-10 bg-white/5 backdrop-blur-md rounded-2xl border border-white/10"
              data-testid="sovereignty-independence"
            >
              <Shield className="w-8 h-8 text-photonic-cyan mb-6" />
              <h3 className="text-2xl font-bold mb-4">Sovereign Fabrication</h3>
              <p className="text-white/70 leading-relaxed">
                Our chip fabrication is fully European. From wafer processing to
                packaging, every critical step happens within sovereign
                semiconductor infrastructure.
              </p>
              <div className="flex flex-wrap gap-2 mt-6">
                {["Sovereign Fab", "European IP", "Local Supply"].map((tag, i) => (
                  <span
                    key={i}
                    className="px-3 py-1 text-xs uppercase tracking-wider bg-photonic-cyan/10 text-photonic-cyan rounded"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>

            <div
              className="p-10 bg-white/5 backdrop-blur-md rounded-2xl border border-white/10"
              data-testid="sovereignty-leadership"
            >
              <Sparkles className="w-8 h-8 text-plasma-violet mb-6" />
              <h3 className="text-2xl font-bold mb-4">Novel PIC Architecture</h3>
              <p className="text-white/70 leading-relaxed">
                We are not iterating on legacy silicon. We are creating
                an entirely new photonic circuit foundation for computational intelligence.
              </p>
              <div className="flex flex-wrap gap-2 mt-6">
                {["Proprietary PIC", "Post-Silicon", "Innovation"].map((tag, i) => (
                  <span
                    key={i}
                    className="px-3 py-1 text-xs uppercase tracking-wider bg-plasma-violet/10 text-plasma-violet rounded"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="mt-32 flex flex-col sm:flex-row items-center justify-center gap-8 sm:gap-16">
          <div className="text-center">
            <div className="text-4xl md:text-6xl font-bold font-mono text-photonic-cyan">
              100%
            </div>
            <div className="text-sm text-white/70 mt-2 uppercase tracking-wider">European</div>
          </div>
          <div className="hidden sm:block w-px h-16 bg-white/10" />
          <div className="block sm:hidden w-16 h-px bg-white/10" />
          <div className="text-center">
            <div className="text-4xl md:text-6xl font-bold font-mono text-plasma-violet">
              Sovereign
            </div>
            <div className="text-sm text-white/70 mt-2 uppercase tracking-wider">Architecture</div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="relative border-t border-white/10" data-testid="footer">
      <div className="max-w-7xl mx-auto px-5 sm:px-8 py-16 sm:py-24">
        <div>
          <span className="font-bold text-3xl tracking-tight" data-testid="footer-logo">HOLO</span>
          <p className="text-white/50 text-sm mt-4 max-w-md leading-relaxed">
            Pioneering photonic integrated circuits for the post-silicon era. European deep-tech sovereignty in next-generation chip architecture.
          </p>
        </div>

        <div className="mt-16 pt-8 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-xs text-white/30">
            © {new Date().getFullYear()} HOLO. All rights reserved.
          </div>
          <div className="text-xs text-white/30">
            Designed & Engineered in Europe
          </div>
        </div>
      </div>
    </footer>
  );
}

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <Navigation />
      <HeroSection />
      <ChipSection />
      <SafetySection />
      <SovereigntySection />
      <Footer />
    </div>
  );
}
